#pragma once
#include "Terminal.h"

extern Terminal gTerm;

void doPwd(int argc, char * argv[]);